from math import pi
from receipt import print_receipt

# Domino's Prices
LARGE_PRICE = 14.99
MEDIUM_PRICE = 12.99
SMALL_PRICE = 9.99

# Radii (in inches)
LARGE_RADIUS = 10
MEDIUM_RADIUS = 8
SMALL_RADIUS = 6

# Sales Tax (Chicago ~10.25%)
SALES_TAX_RATE = 0.1025


def calculate_pizzas(guests):
    """
    Allocate pizzas based on the number of guests using typical servings.

    Rules:
        - 1 large pizza feeds 7 people
        - 1 medium pizza feeds 3 people
        - 1 small pizza feeds 1 person

    Parameters:
        guests (int): Number of guests.

    Returns:
        tuple: (large, medium, small) pizza counts.
    """
    # TODO: implement logic to allocate pizzas based on guests
    large = 0
    medium = 0
    small = 0

    return large, medium, small


def serving_size(large, medium, small):
    """
    Compute the total surface area of all pizzas ordered in square inches.

    Parameters:
        large (int): Number of large pizzas.
        medium (int): Number of medium pizzas.
        small (int): Number of small pizzas.

    Returns:
        float: Total area of pizzas in square inches.
    """
    # TODO: implement logic to calculate total area of pizzas
    area_large = 0
    area_medium = 0
    area_small = 0

    return area_large + area_medium + area_small


def apply_discount(subtotal, guests):
    """
    Apply an automatic discount based on group size.

    Rules:
        5–9 guests   -> 5% off
        10–14 guests -> 10% off
        15+ guests   -> 15% off

    Parameters:
        subtotal (float): Cost before discount.
        guests (int): Number of guests.

    Returns:
        tuple: (discounted subtotal, discount rate applied as a decimal).
    """
    # TODO: implement logic to calculate discounted subtotal and rate
    discount_rate = 0.0
    discounted_subtotal = subtotal

    return discounted_subtotal, discount_rate


def calculate_cost(discounted_subtotal, tip_percentage):
    """
    Compute the total cost including sales tax and tip.

    Parameters:
        discounted_subtotal (float): Subtotal after discount.
        tip_percentage (float): Tip percentage to add.

    Returns:
        tuple: (tax amount, tip amount, total including tax and tip).
    """
    # TODO: implement logic to calculate tax, tip, and total
    tax = 0.0
    tip_amount = 0.0
    total = discounted_subtotal

    return tax, tip_amount, total

def main():
    print("\nWelcome to Blackstone Brick Oven!\n")

    # TODO: Prompt for the number of guests and calculate the number of pizzas -- Refer to output Example
    guests = 0  # Replace with user input later

    # DO NOT EDIT: Calculate number of pizzas needed
    large, medium, small = calculate_pizzas(guests)

    # DO NOT EDIT: Calculate total serving area
    area_sq_in = serving_size(large, medium, small)
    area_sq_ft = area_sq_in / 144

    # TODO: Display pizza summary -- Refer to output Example
    print(f"...")
    print(f"...")

    # TODO: Prompt for tip percentage and display message -- Refer to output Example
    tip_percentage = 0.0  # Replace with user input
    print("...")

    # TODO: Calculate the subtotal based on quantity and price per pizza size
    subtotal = 0  # Replace with calculation

    # DO NOT EDIT: Apply discounts (if any)
    discounted_subtotal, discount_rate = apply_discount(subtotal, guests)

    # TODO: Display discount message IF discount_rate is greather than 0 -- Refer to output Example
    print(f"...")

    # DO NOT EDIT: Calculate final costs
    tax, tip_amount, total = calculate_cost(discounted_subtotal, tip_percentage)

    # DO NOT EDIT BELOW THIS POINT: Print the final receipt
    print_receipt(
        guests,
        large, medium, small,
        subtotal, discounted_subtotal,
        discount_rate, tax, tip_amount, total
    )

if __name__ == "__main__":
    main()
