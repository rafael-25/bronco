# 🍕 Blackstone Brick Oven Pizza Lab

Welcome to **Blackstone Brick Oven**, the busiest pizza shop in town! The pizzeria is known for serving huge groups of hungry customers — from sports teams to entire classrooms. Every order is carefully calculated to make sure there’s enough pizza for everyone, and the register produces a professional receipt with totals, tax, tip, and even discounts for large groups.

---

## 📄 Output Example

When everything is working, the program will generate receipts like this:
```
Welcome to Blackstone Brick Oven!

Enter the number of guests: 11
For 11 guests, you will receive 1 large, 1 medium, and 1 small pizzas.
That's about 345.58 square inches of pizza (~2.40 square feet)!

Enter tip percentage (e.g., 10 for 10%): 10
All tips go toward the Kenwood Broncos Bus Travel Fund.

Congratulations! You qualify for a 10% discount.

===== Blackstone Pizzeria Receipt ========
Guests:                                 11
Large Pizzas:                            1
Medium Pizzas:                           1
Small Pizzas:                            1
Subtotal:                     $      37.97
Discount (10%):              -$       3.80
Subtotal after discount:      $      34.17
Sales Tax:                    $       3.50
Tip:                          $       3.77
Total:                        $      41.44
==========================================
```

## But there’s a problem...

Recently, the **receipt generator has malfunctioned**. The main program still runs, but the important helper functions that handle the calculations are broken. That means the program can’t:

- Decide how many large, medium, and small pizzas to order.
- Compute how many square inches (and square feet) of pizza are being served.
- Apply automatic discounts for big groups.
- Add sales tax and tip to get the final total.

Without these functions, the pizza shop can’t produce accurate **order summaries** or **receipts** for its customers.

I tried to create the same reciept as above and just look at what happened!
```
Welcome to Blackstone Brick Oven!

...
...
...
...
===== Blackstone Brick Oven Reciept ======
Guests:                                 11
Large Pizzas:                            0
Medium Pizzas:                           0
Small Pizzas:                            0
Subtotal:                     $       0.00
Sales Tax:                    $       0.00
Tip:                          $       0.00
Total:                        $       0.00
==========================================
```

## 📝 Your Task

You have been hired as the newest software engineer at **Blackstone Brick Oven**. Your job is to **fix the broken functions** so the register can start generating receipts again.

The main program (`main()`) has been partially written for you and it should:
- Ask for the number of guests.
- Tell you how many pizzas to order.
- Ask if you want to leave a tip.
- Print out a formatted receipt with all the details.

**You will need to format the print and input statements to match the sample outputs.**

### Your other responsibility is to implement the missing helper functions:

1. **`calculate_pizzas`** → determine how many large, medium, and small pizzas are needed for a given number of guests.
2. **`serving_size`** → compute the total surface area of all the pizzas ordered.
3. **`apply_discount`** → apply an automatic discount based on the number of guests.
4. **`calculate_cost`** → calculate sales tax, tip, and final total.

Once you’ve written these functions, the receipt generator will be back in action — and the Broncos will have pizza for their bus trips again!

---

### Task 0: Clean Up the `main()` Function

#### Description

Before you start writing code for the pizza calculations, your first job is to
make the `main()` function clean and easy to read.

The program already runs, but the formatting is messy and the placeholders
are confusing. Fix it so it’s organized and ready for you to complete the tasks that follow.

**Your Goals**

- Keep all DO NOT EDIT sections exactly as they are.

- Complete all TODO comments. Remove unnecessary placeholders (like 0 or "...").

**Hints**

- Look at the example output in the lab instructions to see where inputs and messages should go.

- Focus only on formatting and clarity — don’t change any logic yet.

#### Your output will looking something like this:
```text
Enter the number of guests: 11
For 11 guests, you will receive 0 large, 0 medium, and 0 small pizzas.
That's about 0.00 square inches of pizza (~0.00 square feet)!

Enter tip percentage (e.g., 10 for 10%): 20
All tips go toward the Kenwood Broncos Bus Travel Fund.
```
---

### Task 1: `calculate_pizzas`

#### Description
The `calculate_pizzas` function figures out how many large, medium, and small pizzas are needed to serve a group of guests.

At Blackstone Brick Oven:
- Large feeds **7 people**
- Medium feeds **3 people**
- Small feeds **1 person**

Your goal is to use the fewest pizzas possible while making sure everyone is fed.

**Example:**
- 10 guests → 1 large + 1 medium
- 25 guests → 3 large + 2 medium + 1 small

---

### Task 2: `serving_size`

#### Description
The `serving_size` function calculates the **total surface area** of the pizzas ordered in square inches.

Use the formula for the area of a circle:
**Area = π × (radius²)**

The radius is half the diameter of the pizza.

**Example:**
1 large + 2 medium = about **716.28 square inches**.

---

### Task 3: `apply_discount`

#### Description
The `apply_discount` function applies an automatic discount for big groups.

At Blackstone Brick Oven:
- 5–9 guests → 5% off
- 10–14 guests → 10% off
- 15+ guests → 15% off

The function should return the **subtotal after the discount** and the **discount rate** that was applied.

**Example:**
Subtotal = $100 with 12 guests → 10% off → $90 after discount.

---

### Task 4: `calculate_cost`

#### Description
The `calculate_cost` function adds up the **sales tax** and **tip** to get the final total.

Steps:
1. Add sales tax to the discounted subtotal.
2. Add the tip (a percentage of the total with tax).
3. Return the amounts for tax, tip, and the final total.

**Example:**
Discounted subtotal = $90
Tax = $9.23
Tip (15%) = $14.89
**Final total = $114.12**

---
