def print_receipt(guests, large, medium, small, subtotal, discounted_subtotal,
                  discount_rate, tax, tip_amount, total):
    """
    Print a formatted receipt for the pizza order.
    """
    label_width = 30
    money_width = 12

    print("===== Blackstone Brick Oven Receipt ======")
    print(f"{'Guests:':<{label_width}}{guests:>{money_width}}")
    print(f"{'Large Pizzas:':<{label_width}}{large:>{money_width}}")
    print(f"{'Medium Pizzas:':<{label_width}}{medium:>{money_width}}")
    print(f"{'Small Pizzas:':<{label_width}}{small:>{money_width}}")
    print(f"{'Subtotal:':<{label_width}}${subtotal:>{money_width-1}.2f}")

    if discount_rate > 0:
        discount_amount = subtotal - discounted_subtotal
        print(f"{'Discount (' + str(int(discount_rate*100)) + '%):':<{label_width-1}}"
              f"-${discount_amount:>{money_width-1}.2f}")
        print(f"{'Subtotal after discount:':<{label_width}}${discounted_subtotal:>{money_width-1}.2f}")

    print(f"{'Sales Tax:':<{label_width}}${tax:>{money_width-1}.2f}")
    print(f"{'Tip:':<{label_width}}${tip_amount:>{money_width-1}.2f}")
    print(f"{'Total:':<{label_width}}${total:>{money_width-1}.2f}")
    print("==========================================")
