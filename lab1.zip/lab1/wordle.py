import random

# Task 1: Validate and Get Player's Guess
def get_player_guess(word_list):
    """
    Requests an input from the user and re-requests a guess until the guess is valid.
    A valid guess is a five-character string containing only letters and is a valid word.

    :param word_list (set[str]): The set of valid words for the game.
    :return (str): A valid 5-letter word entered by the player.
    """
    pass  # TODO: Delete this line and then implement the logic below

    # WHILE True:

        # PROMPT the user to enter a 5-letter word

        # IF the word is NOT 5 letters long PRINT appropriate message

        # ELIF the word contains NON-LETTERS PRINT appropriate message

        # ELIF the word is NOT in the WORD LIST PRINT appropriate message

        # ELSE return the word


# Task 2: Check if the Player has Won
def has_won(secret, guess):
    """
    Checks if the player's guess matches the secret word. If the guess matches,
    this function should break the loop in the main game. Should be case-insensitive.

    :param secret (str): The secret word to be guessed.
    :param guess (str): The word entered by the player.
    :return (bool): True if the guess matches the secret word, False otherwise.
    """
    pass  # TODO: Delete this line and then implement the logic below

    # IF the guess MATCHES the secret word RETURN True

    # ELSE RETURN False


# Task 3: Generate Feedback for the Player's Guess
def give_feedback(secret, guess):
    """
    Generates feedback for a guessed word:
        - 🟩 for correct letter in the correct position
        - 🟨 for correct letter in the wrong position
        - ⬜ for incorrect letter

    :param secret (str): The secret word to be guessed.
    :param guess (str): The word entered by the player.
    :return (str): A string of emoji symbols representing feedback for the guess.
    """
    pass  # TODO: Delete this line and then implement the logic below

    # CREATE an empty list called feedback

    # FOR each LETTER in the guess (loop 5 times):

        # IF the letter is in the CORRECT POSITION APPEND 🟩 to feedback

        # ELIF the letter is IN the secret word but WRONG POSITION APPEND 🟨

        # ELSE the letter is NOT in the secret word APPEND ⬜

    # JOIN and return the feedback


# Task 4: Display the Game State
def display_game_state(guess, feedback):
    """
    Displays the guessed word along with its feedback in the format:
    <GUESS> | <FEEDBACK>

    :param guess (str): The guessed word entered by the player.
    :param feedback (str): The emoji feedback string corresponding to the guess.
    :return (None): Displays the current game state.
    """
    pass  # TODO: Delete this line and then implement the logic below

    # PRINT the guess in UPPERCASE followed by a bar and the feedback


# Task 5: Main Game Loop
def play_wordle(secret, word_list):
    """
    The main game loop for the Woordle Clone.

    You MUST:
      - use the functions you wrote in Tasks 1–4
      - while loop to run the game
      - allow up to 6 guesses
      - end early if the player wins
      - show the correct output format (see README example)

    Use the examples in the README.md file to guide your structure.
    """
    # TODO: Implement the full game loop here.


# DO NOT EDIT BELOW THIS LINE EXCEPT IF YOU WANT TO DISPLAY THE SECRET WORD
if __name__ == "__main__":
    # OPEN the file containing all valid guess words and STORE them in a set
    # (Supports words separated by spaces or newlines)
    with open("wordlist.txt", "r") as f:
        WORDLIST = {word.lower() for word in f.read().split()}

    # PICK a random secret word for today's game
    secret_word = random.choice(list(WORDLIST)).lower()

    SHOW_SECRET = False  # Set to True to see the secret word

    if SHOW_SECRET:
        print("DEBUG:", secret)

    print("Welcome to the Woordle Clone!\nCan you solve the challenge of the day?\n\n")

    # START the Wordle game and PASS the secret word and the word list
    play_wordle(secret_word, WORDLIST)
