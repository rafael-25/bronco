# Lab 1
![Wordle Screenshot](wordle.png)

## Overview

**Woordle** is a game popularized by the New York Times where you have six chances to guess a five-letter word. The online version of this game incorporates color hints to guide players toward the correct word by indicating which letters are correct, misplaced, or not in the word.

In this lab, you will implement a text-based version of the game, focusing on coding logic to check guesses, provide feedback, and determine the outcome of the game. This lab reinforces skills in string manipulation, lists, loops, and conditionals.


**Note:** This lab uses the real wordle list. Therefore, your program will behave differently every time.

## Task 1: `has_won(secret, guess)`

### Description
Write a function that checks if the player's guess matches the secret word. If the guess matches, this function will signal to the main game loop that the game is over.

## Example

```bash
secret = "crane"
guess = "crane"
has_won(secret, guess)  # Output: True

secret = "crane"
guess = "plane"
has_won(secret, guess)  # Output: False
```

## Task 2: `get_player_guess()`

### Description
Write a function that prompts the player for a valid 5-letter word and re-requests input until the guess meets all validation requirements.


## Example
```bash
Enter a 5-letter word: cr4ne
Invalid word! Your guess must contain only letters.

Enter a 5-letter word: cranee
Invalid word! Your guess must be exactly 5 letters.

Enter a 5-letter word: abcde
Invalid word! That word is not in the wordlist.

Enter a 5-letter word: crane
CRANE | ⬜🟩⬜⬜⬜
5 guesses left.
```

## Task 1: `has_won(secret, guess)`

### Description
Write a function that checks if the player's guess matches the secret word. If the guess matches, this function will signal to the main game loop that the game is over.

## Example

```bash
secret = "crane"
guess = "crane"
has_won(secret, guess)  # Output: True

secret = "crane"
guess = "plane"
has_won(secret, guess)  # Output: False
```

## Task 3: `get_feedback(guess)`

### Description
Write a function that generates feedback for the player's guess based on its similarity to the secret word. Feedback should use the following symbols:
- 🟩: Correct letter in the correct position.
- 🟨: Correct letter in the wrong position.
- ⬜: Letter not in the secret word.

## Example
```python
# Example 1
secret = "crane"
guess = "crane"
give_feedback(secret, guess)  # Output: "🟩🟩🟩🟩🟩"

# Example 2
secret = "crane"
guess = "crate"
give_feedback(secret, guess)  # Output: "🟩🟩🟩⬜🟩"

# Example 3
secret = "crane"
guess = "cakes"
give_feedback(secret, guess)  # Output: "🟩⬜⬜🟨⬜"
```
## Task 4: `display_game_state(guess, feedback)`

### Description
Write a function that displays the current game state by formatting the player's guess and its corresponding feedback. The output should be in the format:

- `<GUESS> | <FEEDBACK>`

## Example
```python
# Example 1
guess = "crane"
feedback = "🟩🟩🟩🟩🟩"

display_game_state(guess, feedback)
CRANE | 🟩🟩🟩🟩🟩 # Printed Output

# Example 2
guess = "crate"
feedback = "🟩🟩🟩⬜🟩"

display_game_state(guess, feedback)
CRATE | 🟩🟩🟩⬜🟩 # Printed Output
```

## Task 5: Main Game Loop

### Description
Write a function that serves as the main game loop for the Wordle Clone. This function will manage the entire game flow:
- Players guess the secret word within a limited number of attempts.
- Feedback is generated for each guess.
- The game ends when the player guesses the word correctly or runs out of attempts.

Here are some sample program runs with the secret word being **MANGO**.

### Sample Program Run A
```bash
Welcome to the Woordle Clone!
Can you solve the word of the day?

Enter a 5-letter word: green
GREEN | ⬜⬜⬜⬜⬜
5 guesses left.

Enter a 5-letter word: tower
TOWER | ⬜⬜⬜⬜⬜
4 guesses left.

Enter a 5-letter word: clamp
CLAMP | ⬜⬜⬜🟨⬜
3 guesses left.

Enter a 5-letter word: mania
MANIA | 🟩🟨🟨⬜🟨
2 guesses left.

Enter a 5-letter word: mango
MANGO | 🟩🟩🟩🟩🟩
Congrats! You've solved today's challenge!
```

### Sample Program Run B
```bash
Welcome to the Woordle Clone!
Can you solve the word of the day?

Enter a 5-letter word: sheep
SHEEP | ⬜⬜⬜⬜⬜
5 guesses left.

Enter a 5-letter word: round
ROUND | ⬜🟨⬜🟨⬜
4 guesses left.

Enter a 5-letter word: clamp
CLAMP | ⬜⬜🟨🟨⬜
3 guesses left.

Enter a 5-letter word: among
AMONG | 🟨🟨🟨🟨🟨
2 guesses left.

Enter a 5-letter word: manor
MANOR | 🟩🟩🟩🟨⬜
1 guess left.

Enter a 5-letter word: magic
MAGIC | 🟩🟩🟨⬜⬜
0 guesses left.

Game Over! The word was: mango
```

## Acknowledgment

This assignment was adapted from Nifty Assignments. I take no credit for its creation and have only adapted it for instructional purposes.
